# Figure descriptions for accessibility

**Figure 1.** A three-column flow diagram. The left column is Prediction and contains Candidate generator, Local text model, and Flat rule/cue adapter. The center column is Evidence graph and contains Sentence plus exact span, Annotations plus consensus, Rules plus cues plus source links, and Queryable audit state. The right column is Review and release and contains Risk-coverage score, Teacher review packet, Versioned decision event, and Claim-evidence ledger. Arrows connect prediction to traceable graph state and graph state to review routing.

**Figure 2.** A split diagram. Authority500-Full contains 468 sentence groups, 500 raw records, and 495 unique exact keys. It branches into Primary-477 with 477 consistent records and 472 keys, and Flagged-23 with 23 provisional records. The Primary branch leads to a 98-record, 96-key, 90-group test; the Full branch leads to a 104-record, 102-key, 94-group test with six flagged records.

**Figure 3.** A line chart with automatic coverage on the horizontal axis and joint risk on the vertical axis. The four points are 100% coverage and .156 risk, 90% and .070, 80% and .053, and 70% and .030. The line slopes downward as more cases are routed to review. An annotation states that 29 keys are routed at 70% coverage.
